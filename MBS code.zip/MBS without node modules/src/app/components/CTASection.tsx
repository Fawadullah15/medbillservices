import { ArrowRight } from 'lucide-react';

export function CTASection() {
  return (
    <section className="bg-[#8B0000] py-16 md:py-24">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-4xl md:text-6xl font-bold text-white mb-8">
          Ready to Optimize Your Revenue?
        </h2>
        <p className="text-white text-lg md:text-xl max-w-3xl mx-auto mb-12">
          Join the healthcare providers who have increased their collections by 10% in the first 90
          days.
        </p>
        <button
  onClick={() => window.open("https://wa.me/923018345916", "_blank")}
  className="bg-white text-[#8B0000] px-10 py-4 rounded-lg hover:bg-gray-100 transition-colors inline-flex items-center gap-3 text-lg font-semibold group"
>
  Schedule Your Free Audit
  <ArrowRight className="w-6 h-6 group-hover:translate-x-1 transition-transform" />
</button>

      </div>
    </section>
  );
}
