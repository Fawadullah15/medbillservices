import { Linkedin, Instagram, Facebook, Phone, Mail, MapPin, ArrowUp } from 'lucide-react';

export function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#1a1a1a] text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Connect With Our Team */}
          <div>
            <h3 className="text-xl font-bold mb-6">Connect With Our Team</h3>
            <div className="flex gap-4">
              <a
  href="https://www.linkedin.com/company/mbs-medbill-services-llc/?viewAsMember=true"
  target="_blank"
  rel="noopener noreferrer"
  className="w-12 h-12 bg-[#8B0000] rounded-lg flex items-center justify-center hover:bg-[#660000] transition-colors"
>
  <Linkedin className="w-6 h-6" />
</a>

<a
  href="https://www.instagram.com/mbsmedbillservicesllc/"
  href="https://www.instagram.com/mbsmedbillservicesllc/"
  target="_blank"
  rel="noopener noreferrer"
  className="w-12 h-12 bg-[#8B0000] rounded-lg flex items-center justify-center hover:bg-[#660000] transition-colors"
>
  <Instagram className="w-6 h-6" />
</a>

<a
  href="https://www.facebook.com/profile.php?id=61579600834362"
  target="_blank"
  rel="noopener noreferrer"
  className="w-12 h-12 bg-[#8B0000] rounded-lg flex items-center justify-center hover:bg-[#660000] transition-colors"
>
  <Facebook className="w-6 h-6" />
</a>

            </div>
          </div>

          {/* Quick Links */}
         <div>
  <h3 className="text-xl font-bold mb-6">Services</h3>
  <ul className="space-y-2 text-gray-400">
    <li>Medical Billing</li>
    <li>Credentialing</li>
    <li>Coding</li>
    <li>Virtual Assistant / Scheduler</li>
    <li>Patient Help Desk</li>
    <li>SEO Marketing</li>
    <li>AR Follow Up</li>
    <li>Whole RCM</li>
  </ul>
</div>

          {/* Contact Us */}
          <div>
            <h3 className="text-xl font-bold mb-6">Contact Us</h3>
            <div className="space-y-4">
              <a
                href="tel:+15123684587"
                className="flex items-start gap-3 text-gray-300 hover:text-white transition-colors"
              >
                <div className="w-10 h-10 bg-[#8B0000] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <span>+1 (512) 368-4587</span>
              </a>
              <a
                href="mailto:info@medbillservicesllc.com"
                className="flex items-start gap-3 text-gray-300 hover:text-white transition-colors"
              >
                <div className="w-10 h-10 bg-[#8B0000] rounded-lg flex items-center justify-center flex-shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <span>info@medbillservicesllc.com</span>
              </a>
              <div className="flex items-start gap-3 text-gray-300">
                <div className="w-10 h-10 bg-[#8B0000] rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  10411 Oak Forest Way STE 43
                  <br />
                  New Braunfels, TX 78132
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-700 pt-8">
          <div className="bg-[#2a2a2a] rounded-lg p-6 mb-8">
            <h4 className="text-lg font-semibold mb-2">Privacy Policy</h4>
          </div>

          <div className="text-center text-gray-400 text-sm">
            © 2026 MedBillServices LLC. All rights reserved.
          </div>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-8 right-8 w-14 h-14 bg-cyan-400 rounded-lg flex items-center justify-center hover:bg-cyan-300 transition-colors shadow-lg z-50"
        aria-label="Scroll to top"
      >
        <ArrowUp className="w-6 h-6 text-gray-800" />
      </button>
    </footer>
  );
}
