import { useState } from 'react';
import { Menu, X, ChevronDown } from 'lucide-react';

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);

  return (
    <header className="bg-white border-b-4 border-[#8B0000] sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#8B0000] rounded-full flex items-center justify-center">
              <div className="text-white text-xl">✚</div>
            </div>
            <span className="text-2xl font-bold text-[#8B0000]">MBS</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <a href="#home" className="text-gray-700 hover:text-[#8B0000] transition-colors">
              Home
            </a>
            <a href="#specialties" className="text-gray-700 hover:text-[#8B0000] transition-colors">
              Specialties
            </a>
            <div className="relative">
              <button
                onClick={() => setServicesOpen(!servicesOpen)}
                className="flex items-center gap-1 text-gray-700 hover:text-[#8B0000] transition-colors"
              >
                Services
                <ChevronDown className="w-4 h-4" />
              </button>
              {servicesOpen && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white shadow-lg rounded-lg py-2">
                  <a href="#billing" className="block px-4 py-2 hover:bg-gray-100">
                    Medical Billing & Coding
                  </a>
                  <a href="#credentialing" className="block px-4 py-2 hover:bg-gray-100">
                    Credentialing & Enrollment
                  </a>
                  <a href="#accounts" className="block px-4 py-2 hover:bg-gray-100">
                    Accounts Receivable
                  </a>
                  <a href="#denial" className="block px-4 py-2 hover:bg-gray-100">
                    Denial Management
                  </a>
                </div>
              )}
            </div>
            <a href="#about" className="text-gray-700 hover:text-[#8B0000] transition-colors">
              About
            </a>
            <button className="bg-[#8B0000] text-white px-6 py-2.5 rounded-lg hover:bg-[#660000] transition-colors">
              Contact Us
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t">
            <a href="#home" className="block py-2 text-gray-700">
              Home
            </a>
            <a href="#specialties" className="block py-2 text-gray-700">
              Specialties
            </a>
            <a href="#services" className="block py-2 text-gray-700">
              Services
            </a>
            <a href="#about" className="block py-2 text-gray-700">
              About
            </a>
            <button className="w-full mt-4 bg-[#8B0000] text-white px-6 py-2.5 rounded-lg">
              Contact Us
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
