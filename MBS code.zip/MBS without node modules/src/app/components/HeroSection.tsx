import { ArrowRight } from 'lucide-react';

export function HeroSection() {
  return (
    <section id="home" className="bg-[#F5F5F5] py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <div className="flex items-center gap-2 mb-6">
              <div className="w-2 h-2 bg-[#8B0000] rounded-full"></div>
              <span className="text-[#8B0000] uppercase tracking-wider text-sm">
                MEDICAL BILLING SERVICES
              </span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold mb-8">
              <span className="text-gray-800">All-in-One</span>
              <br />
              <span className="text-[#8B0000]">Medical</span>
              <br />
              <span className="text-gray-800">Billing</span>
              <br />
              <span className="text-gray-800">Services</span>
              <br />
              <span className="text-gray-800">LLC</span>
            </h1>
          </div>

          <div className="relative">
            <img
              src="https://mzbilling.com/wp-content/uploads/2025/07/Doctors-Looking-at-MZ-Medical-Billing-Results-1-1024x637.jpeg"
              alt="Healthcare team"
              className="w-full h-auto rounded-lg shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
