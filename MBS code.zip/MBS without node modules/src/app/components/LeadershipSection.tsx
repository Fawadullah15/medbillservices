import { ArrowRight } from 'lucide-react';

export function LeadershipSection() {
  return (
    <section id="leadership" className="bg-white py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <div className="absolute inset-0 border-4 border-[#8B0000] rounded-lg transform translate-x-4 translate-y-4"></div>
            <img
              src="https://framerusercontent.com/images/5ZXdb7LrjfXLAtUiFIcdAAQBQc.jpeg?width=804&height=862"
              alt="Dr. Evelyn Reed"
              className="relative w-full h-auto rounded-lg shadow-xl"
            />
          </div>

          <div>
            <div className="text-[#8B0000] uppercase tracking-wider text-sm mb-4">
              LEADERSHIP
            </div>
            <h2 className="text-5xl md:text-6xl font-bold text-gray-800 mb-4">
              Sabahat Ali
            </h2>
            <p className="text-gray-500 text-xl mb-8">Chief Executive Officer</p>

            <p className="text-gray-600 leading-relaxed mb-8">
              Mr. Sabahat Ali is an expert in startups, t
              raining, quality control, and client relationship
               management. He leads MBS-MedBill Services LLC, 
               providing
                innovative solutions to enterprises across the nation.
            </p>
<button
  onClick={() => window.open("https://sabahatali.framer.website/", "_blank")}
  className="bg-gray-800 text-white px-8 py-4 rounded-lg hover:bg-gray-700 transition-colors flex items-center gap-2 group"
>
  Dive into my portfolio
  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
</button>


            <div className="mt-8 text-gray-400 text-sm">FOUNDER & CEO</div>
          </div>
        </div>
      </div>
    </section>
  );
}
