import { Activity, ArrowRight } from 'lucide-react';

const services = [
  {
    icon: Activity,
    title: 'Medical Billing & Coding',
    description:
      'Our expert team handles all aspects of medical billing and coding, ensuring accuracy, compliance, and maximum reimbursement for your practice. We stay updated with the latest CPT, ICD-10, and HCPCS codes to minimize errors and accelerate payment cycles.',
    link: 'LEARN MORE',
  },
  {
    icon: Activity,
    title: 'Credentialing & Enrollment',
    description:
      'Streamline your provider credentialing and enrollment process with our dedicated service. We manage all paperwork, applications, and follow-ups with insurance payers to ensure your providers are properly credentialed and can bill for services without delay.',
    link: 'LEARN MORE',
  },
  {
    icon: Activity,
    title: 'Accounts Receivable Management',
    description:
      'Optimize your revenue cycle with our comprehensive Accounts Receivable (AR) management. We meticulously track outstanding claims, follow up on unpaid balances, and implement strategies to reduce your AR days and improve cash flow.',
    link: 'LEARN MORE',
  },
  {
    icon: Activity,
    title: 'Denial Management & Appeals',
    description:
      "Don't let denied claims impact your bottom line. Our specialized denial management team identifies the root causes of denials, files timely appeals, and works diligently to overturn rejections, recovering revenue that might otherwise be lost.",
    link: 'LEARN MORE',
  },
  {
    icon: Activity,
    title: 'Practice Management Consulting',
    description:
      'Transform your practice with strategic consulting services. We analyze your operations, identify inefficiencies, and implement best practices to enhance productivity, reduce costs, and improve patient satisfaction.',
    link: 'LEARN MORE',
  },
  {
    icon: Activity,
    title: 'Compliance & Audit Support',
    description:
      'Stay compliant with ever-changing healthcare regulations. Our team provides comprehensive audit support, compliance reviews, and training to protect your practice from costly violations and ensure adherence to HIPAA and other standards.',
    link: 'LEARN MORE',
  },
];

export function ServicesSection() {
  return (
    <section id="services" className="bg-[#8B0000] py-16 md:py-24 relative overflow-hidden">
      {/* Decorative background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          <path d="M0,50 Q25,20 50,50 T100,50" stroke="white" fill="none" strokeWidth="0.5" />
          <path d="M0,70 Q25,40 50,70 T100,70" stroke="white" fill="none" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Essential <span className="text-white opacity-50">Services</span>
          </h2>
          <p className="text-white text-lg max-w-3xl">
            Comprehensive solutions designed to streamline your revenue cycle and enhance
            operational efficiency. We handle the complexity so you can focus on care.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-8 hover:bg-white/10 transition-all duration-300"
            >
              <div className="w-16 h-16 bg-[#660000] rounded-lg flex items-center justify-center mb-6">
                <service.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-4">{service.title}</h3>
              <p className="text-white/80 mb-6 leading-relaxed">{service.description}</p>
              <button className="flex items-center gap-2 text-cyan-400 font-semibold hover:gap-4 transition-all">
                {service.link}
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
