import { TrendingUp, Shield, ArrowRight } from 'lucide-react';

const reasons = [
  {
    icon: Shield,
    title: 'Unmatched Industry Expertise',
    description:
      'Benefit from decades of collective experience. Our team of certified professionals brings deep industry knowledge to every project, ensuring best-in-class solutions tailored to your needs.',
    link: 'Meet Our Experts',
    bgColor: 'bg-teal-100',
    iconColor: 'text-teal-600',
  },
  {
    icon: TrendingUp,
    title: 'Your Success, Our Priority',
    description:
      'We believe in building lasting partnerships. Our dedicated account managers provide personalized support, ensuring your goals are met with proactive communication and tailored strategies.',
    link: 'Discover Our Approach',
    bgColor: 'bg-pink-100',
    iconColor: 'text-pink-600',
  },
  {
    icon: Shield,
    title: 'Cutting-Edge Technology',
    description:
      'Leverage the latest innovations in healthcare technology. Our proprietary platform integrates seamlessly with your existing systems, providing real-time insights and automated workflows.',
    link: 'Explore Our Innovations',
    bgColor: 'bg-orange-100',
    iconColor: 'text-orange-600',
  },
  {
    icon: Shield,
    title: 'Dependable Service, Guaranteed Results',
    description:
      'Trust MBS for consistent quality and unwavering reliability. We are committed to delivering on our promises, providing secure and stable services you can always count on.',
    link: 'Our Commitment to Quality',
    bgColor: 'bg-purple-100',
    iconColor: 'text-purple-600',
  },
  {
    icon: Shield,
    title: 'End-to-End Solutions for Your Business',
    description:
      'From initial consultation to ongoing support, MBS offers a full spectrum of services designed to cover all your needs. Streamline your operations with a single, trusted partner.',
    link: 'View All Services',
    bgColor: 'bg-blue-100',
    iconColor: 'text-blue-600',
  },
];

export function WhyChooseSection() {
  return (
    <section id="why-choose" className="bg-[#F5F5F5] py-16 md:py-24">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Left Column - Title and Stats */}
          <div>
            <h2 className="text-5xl md:text-6xl font-bold mb-8">
              <span className="text-gray-800">Why Choose</span>
              <br />
              <span className="text-[#8B0000]">MBS?</span>
            </h2>

            <p className="text-gray-600 text-lg mb-12">
              We don't just process claims; we engineer financial stability for your practice
              through technology and expertise.
            </p>

            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">5-10% Increase</div>
                  <div className="text-gray-500">In collections within 3 months</div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">96% Approval</div>
                  <div className="text-gray-500">First-pass claim rate</div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Reasons */}
          <div className="space-y-6">
            {reasons.map((reason, index) => (
              <div
                key={index}
                className="bg-white rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div
                    className={`w-16 h-16 ${reason.bgColor} rounded-lg flex items-center justify-center flex-shrink-0`}
                  >
                    <reason.icon className={`w-8 h-8 ${reason.iconColor}`} />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2">{reason.title}</h3>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">{reason.description}</p>
                <button className="flex items-center gap-2 text-[#8B0000] font-semibold hover:gap-4 transition-all">
                  {reason.link}
                  <ArrowRight className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
